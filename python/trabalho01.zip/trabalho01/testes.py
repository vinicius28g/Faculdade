import sqlite3
import comandos_SQL
import os
caminho_pasta = os.path.join(os.getcwd(), 'Saldos')
print(caminho_pasta)